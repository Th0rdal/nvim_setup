assert(s ~= nil, "defaults loaded")
assert(_s ~= nil, "custom snip_env loaded")
assert(i == true, "custom snip_env overrides defaults")
