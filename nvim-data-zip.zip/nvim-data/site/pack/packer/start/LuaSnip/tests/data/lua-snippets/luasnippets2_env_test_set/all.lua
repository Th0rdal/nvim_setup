assert(s == nil, "defaults not loaded")
assert(_s ~= nil, "custom snip_env loaded")
