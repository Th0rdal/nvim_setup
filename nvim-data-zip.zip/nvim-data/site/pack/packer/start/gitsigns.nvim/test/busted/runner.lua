require('busted.runner')({ standalone = false })
