vim.opt.runtimepath:append(".")
vim.cmd([[runtime! plugin/plenary.vim]])
vim.cmd([[runtime! plugin/cellular-automaton.lua]])
