local M = {}

local settings = require('lsp-zero.settings')
local util = require('lsp-zero.utils')
local state = {ok = false}

local json_encode = vim.fn.json_encode
local json_decode = vim.fn.json_decode

if vim.json then
  json_encode = vim.json.encode
  json_decode = vim.json.decode
end

local get_defaults = function()
  return {
    ok = true,

    -- filetypes to ignore by default
    filetypes = {
      ['lsp-installer'] = true,
      ['mason.nvim'] = true,
      ['null-ls-info'] = true,
      help = true,
      nofile = true,
      qf = true,
      quickfix = true,
      netrw = true,
      lspinfo = true,
      man = true,
      harpoon = true
    },

    -- cache server history
    previously_installed_servers = {}
  }
end

local defaults = get_defaults()

local supported_filetypes = util.get_supported_filetypes

M.sync = function()
  local installer = require('lsp-zero.installer')
  installer.choose()

  local get_installed_servers = installer.fn.get_servers

  local path = settings.state_file
  local new_state = {}

  if vim.fn.filereadable(path) == 0 then
    util.write_file(path, json_encode(defaults))
    new_state = defaults
  else
    state = json_decode(util.read_file(path))
    return
  end

  local servers = get_installed_servers()

  for _, name in ipairs(servers) do
    local fts = supported_filetypes(name)
    new_state.previously_installed_servers[name] = true

    for ft, _ in pairs(fts) do
      if type(ft) == 'string' then
        new_state.filetypes[ft] = true
      end
    end
  end

  util.write_file(path, json_encode(new_state))

  state = new_state
end

M.save_filetype = function(ft)
  local path = settings.state_file

  if not state.ok then
    state = json_decode(util.read_file(path))
  end

  state.filetypes[ft] = true

  util.write_file(path, json_encode(state))
end

M.check_server = function(name)
  if not state.ok then
    return
  end

  if state.previously_installed_servers[name] then
    return
  end

  state.previously_installed_servers[name] = true

  local fts = supported_filetypes(name)
  state.previously_installed_servers[name] = true

  for ft, _ in pairs(fts) do
    if type(ft) == 'string' then
      state.filetypes[ft] = true
    end
  end

  util.write_file(settings.state_file, json_encode(state))
end

M.reset = function()
  state = get_defaults()
  util.write_file(settings.state_file, json_encode(state))
end

M.get = function()
  return state
end

return M

